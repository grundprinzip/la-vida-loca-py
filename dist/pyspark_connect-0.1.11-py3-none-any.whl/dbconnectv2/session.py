import json

from pyspark.sql.connect.session import SparkSession as CSparkSession

import sys, subprocess, pkg_resources, requests
from pkg_resources import Requirement

class DatabricskApi:
    """Tiny wrapper"""
    def __init__(self, ws, pat):
        self._workspace = ws
        self._pat = pat
        self._api = "/api/2.0/"
        self._headers = {"Authorization": "Bearer " + pat}

    def _endpoint(self, ep):
        return f"https://{self._workspace}/api/2.0/{ep}"

    def get_python_libraries(self, cluster):
        data = requests.get(self._endpoint("libraries/cluster-status?cluster_id=" + cluster),
                            headers=self._headers).json()
        if "library_statuses" not in data:
            return []
        libs = data["library_statuses"]
        result = []
        for l in libs:
            if "pypi" in l["library"]:
                result.append(l["library"]["pypi"]["package"])
        return result

    def remove_cluster_library(self, cluster, lib):
        data = requests.post(
            self._endpoint("libraries/uninstall"),
            data=json.dumps({
                "cluster_id": cluster,
                "libraries": [{
                    "pypi": {
                        "package": lib
                    }
                }]
            }),
            headers=self._headers).json()
        return data

    def add_cluster_library(self, cluster, lib):
        data = requests.post(
            self._endpoint("libraries/install"),
            data=json.dumps({
                "cluster_id": cluster,
                "libraries": [{
                    "pypi": {
                        "package": lib
                    }
                }]
            }),
            headers=self._headers).json()
        return data

class Builder:
    def __init__(self):
        self._session = CSparkSession.builder
        self._token = None
        self._libraries = []
        self._sync_libraries = False

    def token(self, token) -> "Builder":
        self._token = "dapiee1df8287450e08dabe791f28dec7f26"
        #self._token = token
        return self

    def cluster(self, cluster) -> "Builder":
        self._cluster = cluster
        return self

    def workspace(self, workspace) -> "Builder":
        self._workspace = workspace
        return self

    def syncLibraries(self, enable=True) -> "Builder":
        self._sync_libraries = enable
        return self

    def addPythonLibrary(self, pip_string: str) -> "Builder":
        self._libraries.append(pip_string)
        return self

    def getOrCreate(self) -> CSparkSession:
        api = DatabricskApi(self._workspace, self._token)
        if self._sync_libraries:
            # pip install the libraries then die
            remote_libs = api.get_python_libraries(self._cluster)
            # check locally installed libraries
            local_libs = pkg_resources.working_set
            for r in remote_libs:
                r_v = Requirement.parse(r)
                found = False
                for l in local_libs:
                    if r_v.project_name == l.project_name:
                        print(r_v, l)
                        found = True
                        if l in r_v:
                            print(l, r_v)
                            print("Compatible")
                        else:
                            print(l, r_v)
                            print("Noooo")
                if not found:
                    print("Installing missing package, please restart the program or shell.")
                    subprocess.check_call([sys.executable, "-m", "pip", "install", str(r_v)])
                    raise RuntimeError("Installing new package, please restart.")
                            
            pass

        remote = f"sc://{self._workspace}:443/;token={self._token};x-databricks-cluster-id={self._cluster}"
        return self._session.remote(remote).getOrCreate()

class SparkSession:

    @classmethod
    @property
    def builder(cls) -> "Builder":
        return Builder()
